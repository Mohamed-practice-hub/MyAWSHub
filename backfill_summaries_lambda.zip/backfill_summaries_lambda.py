import boto3
import json
import datetime
from io import StringIO

s3 = boto3.client('s3')
BUCKET = 'autotrade-automation-data-206055866143-us-east-1'
NDJSON_PREFIX = 'data/history/daily/symbol={symbol}/date={date}/data.ndjson'
SUMMARY_PREFIX = 'site/signals/history/{date}.json'
DEFAULT_SYMBOLS = ['NSE-INFY', 'NSE-TCS', 'NSE-RELIANCE']

# --- Indicator calculations ---
def compute_indicators(ohlc):
    closes = [float(x['close']) for x in ohlc if 'close' in x]
    if not closes:
        return None
    def ma(arr, n):
        return sum(arr[-n:]) / n if len(arr) >= n else None
    ma5 = ma(closes, 5)
    ma20 = ma(closes, 20)
    ma200 = ma(closes, 200)
    last_close = closes[-1]
    # RSI(14)
    rsi14 = None
    if len(closes) >= 15:
        gains = sum(max(closes[i] - closes[i-1], 0) for i in range(-14, 0))
        losses = sum(-min(closes[i] - closes[i-1], 0) for i in range(-14, 0))
        avg_gain = gains / 14
        avg_loss = losses / 14
        if avg_loss == 0:
            rsi14 = 100
        else:
            rs = avg_gain / avg_loss
            rsi14 = 100 - (100 / (1 + rs))
    # MACD (12,26,9)
    def ema(arr, n):
        if len(arr) < n: return None
        k = 2 / (n + 1)
        ema_prev = sum(arr[:n]) / n
        for i in range(n, len(arr)):
            ema_prev = arr[i] * k + ema_prev * (1 - k)
        return ema_prev
    macd = macd_signal = macd_hist = None
    if len(closes) >= 26:
        macd_line = ema(closes, 12) - ema(closes, 26)
        macd = macd_line
        macd_arr = [ema(closes[i-25:i+1], 12) - ema(closes[i-25:i+1], 26) for i in range(25, len(closes))]
        macd_signal = ema(macd_arr, 9)
        macd_hist = macd - macd_signal if macd_signal is not None else None
    return {
        'lastClose': last_close,
        'ma5': ma5,
        'ma20': ma20,
        'ma200': ma200,
        'rsi14': rsi14,
        'macd': macd,
        'macdSignal': macd_signal,
        'macdHist': macd_hist
    }

def lambda_handler(event, context):
    # Parameters: days, symbols
    days = int(event.get('days', 30))
    symbols = event.get('symbols', DEFAULT_SYMBOLS)
    today = datetime.date.today()
    for i in range(days):
        date_obj = today - datetime.timedelta(days=i)
        date_str = date_obj.strftime('%Y-%m-%d')
        summary_key = SUMMARY_PREFIX.format(date=date_str)
        # Check if summary file exists
        try:
            s3.head_object(Bucket=BUCKET, Key=summary_key)
            print(f"Exists: {summary_key}")
            continue  # Skip if exists
        except s3.exceptions.ClientError:
            pass  # Not found, proceed
        rows = []
        for symbol in symbols:
            ndjson_key = NDJSON_PREFIX.format(symbol=symbol, date=date_str)
            try:
                resp = s3.get_object(Bucket=BUCKET, Key=ndjson_key)
                ndjson_data = resp['Body'].read().decode('utf-8')
                ohlc = [json.loads(line) for line in ndjson_data.splitlines() if line.strip()]
                if not ohlc:
                    continue
                indicators = compute_indicators(ohlc)
                if not indicators:
                    continue
                row = {
                    'symbol': symbol.replace('-', ':'),
                    'asof': date_str,
                    **indicators,
                    'signal': None,  # Optionally add signal logic here
                }
                rows.append(row)
            except s3.exceptions.ClientError:
                print(f"Missing NDJSON: {ndjson_key}")
                continue
        if rows:
            summary = {
                'generatedAt': datetime.datetime.utcnow().isoformat() + 'Z',
                'rows': rows
            }
            s3.put_object(Bucket=BUCKET, Key=summary_key, Body=json.dumps(summary), ContentType='application/json')
            print(f"Created: {summary_key}")
        else:
            print(f"No data for {date_str}")
    return {'status': 'done'}
