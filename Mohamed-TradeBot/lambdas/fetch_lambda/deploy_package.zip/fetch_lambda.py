

from kiteconnect import KiteConnect
import boto3, os, json
from decimal import Decimal
from datetime import datetime, timedelta
import logging
import time
from collections import defaultdict
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_token(symbol):
    # TODO: Implement token lookup from instruments.csv or DynamoDB
    raise NotImplementedError("get_token() must be implemented")


# Top-level notify_telegram
def notify_telegram(message):
    import requests
    token = os.environ.get('TELEGRAM_BOT_TOKEN')
    chat_id = os.environ.get('TELEGRAM_CHAT_ID')
    if not token or not chat_id:
        logger.warning("TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set, skipping Telegram notification.")
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    logger.info(f"Sending Telegram notification: {message}")
    try:
        requests.post(url, data={'chat_id': chat_id, 'text': message})
    except Exception as e:
        logger.error(f"Telegram notify failed: {e}")

# Top-level notify_email
def notify_email(subject, body):
    ses = boto3.client('ses')
    sender = os.environ.get('SES_FROM')
    recipient = os.environ.get('SES_TO')
    if not sender or not recipient:
        logger.warning("SES email credentials missing")
        return
    logger.info(f"Sending SES email: subject={subject}, body={body}")
    try:
        ses.send_email(
            Source=sender,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': body}}
            }
        )
    except Exception as e:
        logger.error(f"SES notify failed: {e}")

# Top-level lambda_handler
def lambda_handler(event, context):
    logger.info(f"Received event: {event}")
    # Test mode: send a test notification if requested
    try:
        if isinstance(event, dict) and event.get('test_notification'):
            msg = event.get('test_message', 'Test notification from tradebot_fetch_lambda')
            notify_telegram(f"[TEST] {msg}")
            notify_email('Test notification from fetch lambda', msg)
            return {'status': 'test_sent'}
    except Exception:
        logger.exception('Failed running test notification')
    errors = []
    try:
        secret_name = os.environ.get("SECRET_NAME", "autotrade-kite/credentials")
        table_name = os.environ.get("DYNAMODB_TABLE", "tradebot_signals_table")
        default_symbols = os.environ.get("SYMBOLS", "RELIANCE,TCS,INFY").split(",")
        backfill_days = int(event.get("backfilldays", 2))
        symbols = event.get("symbols", default_symbols)

        # Get Kite credentials from Secrets Manager (old code logic)
        sm = boto3.client("secretsmanager")
        sec = sm.get_secret_value(SecretId=secret_name)
        creds = json.loads(sec.get("SecretString") or "{}")
        api_key = creds.get("api_key") or creds.get("KITE_API_KEY")
        access_token = creds.get("access_token")
        if not api_key or not access_token:
            raise RuntimeError("Missing api_key/access_token in secret")

        kite = KiteConnect(api_key=api_key)
        kite.set_access_token(access_token)

        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table(table_name)
        ddb_client = boto3.client('dynamodb')

        today = datetime.now(datetime.utcnow().astimezone().tzinfo).date()

        # Build a list of all (SymbolKey, TradedDate) keys we intend to backfill
        date_strs = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(backfill_days)]
        all_keys = []
        for sym in symbols:
            for ds in date_strs:
                all_keys.append({
                    'SymbolKey': {'S': sym},
                    'TradedDate': {'S': ds}
                })

        # Batch-get existing items (max 100 keys per BatchGetItem request)
        existing = set()
        def chunked(lst, n):
            for i in range(0, len(lst), n):
                yield lst[i:i+n]

        for chunk in chunked(all_keys, 100):
            request_items = {table_name: {'Keys': chunk, 'ProjectionExpression': 'SymbolKey,TradedDate'}}
            while True:
                resp = ddb_client.batch_get_item(RequestItems=request_items)
                for it in resp.get('Responses', {}).get(table_name, []):
                    existing.add((it['SymbolKey']['S'], it['TradedDate']['S']))
                unproc = resp.get('UnprocessedKeys', {})
                if not unproc or not unproc.get(table_name):
                    break
                # retry unprocessed keys
                request_items = unproc
                time.sleep(0.2)

        # Map missing dates per symbol to avoid repeated get calls
        missing_by_symbol = defaultdict(list)
        for sym in symbols:
            for ds in date_strs:
                if (sym, ds) not in existing:
                    missing_by_symbol[sym].append(ds)

        # Iterate symbols and fill only missing dates
        for symbol in symbols:
            if ":" in symbol:
                ex, ts = symbol.split(":")
            else:
                ex, ts = "NSE", symbol
            try:
                instruments = kite.instruments(ex)
            except Exception as e:
                logger.error(f"Failed to fetch instruments for {ex}: {e}")
                errors.append(f"Failed to fetch instruments for {ex}: {e}")
                continue
            token = None
            for inst in instruments:
                if inst["tradingsymbol"] == ts:
                    token = inst["instrument_token"]
                    break
            if not token:
                logger.error(f"Instrument token not found for {symbol}")
                errors.append(f"Instrument token not found for {symbol}")
                continue
            # Only process the dates that are missing
            dates_to_process = missing_by_symbol.get(symbol, [])
            if not dates_to_process:
                logger.info(f"All requested dates exist for {symbol}, skipping backfill.")
                continue
            for ds in dates_to_process:
                date_obj = datetime.strptime(ds, "%Y-%m-%d").date()
                from_dt = datetime.combine(date_obj, datetime.min.time(), tzinfo=datetime.utcnow().astimezone().tzinfo)
                to_dt = from_dt + timedelta(days=1)
                try:
                    candles = kite.historical_data(
                        instrument_token=token,
                        from_date=from_dt,
                        to_date=to_dt,
                        interval="day",
                        continuous=False,
                        oi=False,
                    )
                except Exception as e:
                    logger.error(f"Kite historical_data failed for {symbol} {date_obj}: {e}")
                    errors.append(f"Kite historical_data failed for {symbol} {date_obj}: {e}")
                    continue
                if not candles:
                    logger.warning(f"No data for {symbol} on {date_obj}")
                    continue
                c = candles[0]
                item = {
                    "SymbolKey": symbol,
                    "TradedDate": date_obj.strftime("%Y-%m-%d"),
                    "Open": Decimal(str(c.get("open", 0))),
                    "High": Decimal(str(c.get("high", 0))),
                    "Low": Decimal(str(c.get("low", 0))),
                    "Close": Decimal(str(c.get("close", 0))),
                    "Volume": Decimal(str(c.get("volume", 0))),
                    "Timestamp": datetime.utcnow().isoformat()
                }
                try:
                    # Use conditional put to ensure we do not overwrite existing items
                    table.put_item(
                        Item=item,
                        ConditionExpression='attribute_not_exists(SymbolKey)'
                    )
                    logger.info(f"Inserted (new): {item}")
                except ClientError as e:
                    code = e.response.get('Error', {}).get('Code')
                    if code == 'ConditionalCheckFailedException':
                        logger.info(f"Skipped existing (race): {symbol} {ds}")
                        continue
                    logger.error(f"DynamoDB put_item failed for {symbol} {date_obj}: {e}")
                    errors.append(f"DynamoDB put_item failed for {symbol} {date_obj}: {e}")
        if errors:
            notify_telegram("Fetch Lambda completed with errors:\n" + "\n".join(errors))
            notify_email("Fetch Lambda ERROR", "\n".join(errors))
        else:
            notify_telegram("Fetch Lambda completed successfully for all symbols.")
        return {"status": "done"}
    except Exception as e:
        msg = f"Fetch Lambda ERROR: {str(e)}"
        logger.error(msg)
        notify_telegram(msg)
        notify_email("Fetch Lambda ERROR", msg)
        raise
