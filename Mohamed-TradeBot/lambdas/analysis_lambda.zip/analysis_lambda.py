import os
import json
import logging
import boto3
from decimal import Decimal
from datetime import datetime, timedelta
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


# Notification helpers (Telegram + SES)
def notify_telegram(message):
    try:
        import requests
        token = os.environ.get('TELEGRAM_BOT_TOKEN')
        chat_id = os.environ.get('TELEGRAM_CHAT_ID')
        if not token or not chat_id:
            logger.warning('TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set, skipping Telegram notification.')
            return
        url = f'https://api.telegram.org/bot{token}/sendMessage'
        logger.info(f'Sending Telegram notification: {message}')
        requests.post(url, data={'chat_id': chat_id, 'text': message})
    except Exception as e:
        logger.error(f'Telegram notify failed: {e}')


def notify_email(subject, body):
    try:
        ses = boto3.client('ses')
        sender = os.environ.get('SES_FROM')
        recipient = os.environ.get('SES_TO')
        if not sender or not recipient:
            logger.warning('SES_FROM or SES_TO not set, skipping email notification')
            return
        logger.info(f'Sending SES email: subject={subject}')
        ses.send_email(
            Source=sender,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': body}}
            }
        )
    except Exception as e:
        logger.error(f'SES notify failed: {e}')

DDB_TABLE = os.environ.get('DYNAMODB_TABLE', 'tradebot_signals_table')
REGION = os.environ.get('AWS_REGION', 'us-east-1')

dynamodb = boto3.resource('dynamodb', region_name=REGION)
table = dynamodb.Table(DDB_TABLE)

# Indicator helper functions
import math
import re

def ma(series, period):
    if len(series) < period:
        return None
    return sum(series[-period:]) / period

# RSI using average gains/losses
def rsi(series, period=14):
    if len(series) < period + 1:
        return None
    gains = 0.0
    losses = 0.0
    for i in range(-period, 0):
        delta = series[i] - series[i-1]
        if delta > 0:
            gains += delta
        else:
            losses -= delta
    if gains + losses == 0:
        return 50.0
    rs = (gains / period) / (losses / period) if losses != 0 else float('inf')
    if math.isinf(rs):
        return 100.0
    return 100 - (100 / (1 + rs))

# MACD: EMA12 - EMA26. We'll compute simple EMA
def ema(series, period):
    if len(series) < period:
        return None
    k = 2 / (period + 1)
    ema_prev = sum(series[:period]) / period
    for price in series[period:]:
        ema_prev = (price - ema_prev) * k + ema_prev
    return ema_prev

def macd(series):
    ema12 = ema(series, 12)
    ema26 = ema(series, 26)
    if ema12 is None or ema26 is None:
        return (None, None, None)
    macd_line = ema12 - ema26
    # MACD Signal line (9-period EMA of MACD line) approximate by computing MACD over longer series
    # Simpler: compute MACD series across whole set then EMA9 on it.
    macd_series = []
    # Compute EMA on rolling basis (not efficient but acceptable for small data)
    for i in range(len(series)):
        sub = series[:i+1]
        e12 = ema(sub, 12)
        e26 = ema(sub, 26)
        if e12 is None or e26 is None:
            macd_series.append(None)
        else:
            macd_series.append(e12 - e26)
    macd_series_clean = [v for v in macd_series if v is not None]
    if len(macd_series_clean) < 9:
        return (macd_line, None, None)
    # Compute EMA9 on macd_series_clean
    signal = ema(macd_series_clean, 9)
    hist = None
    if signal is not None and macd_line is not None:
        hist = macd_line - signal
    return (macd_line, signal, hist)

# ATR (Average True Range); uses high/low/close arrays
def atr(highs, lows, closes, period=14):
    if len(highs) < period + 1 or len(lows) < period + 1 or len(closes) < period + 1:
        return None
    trs = []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        trs.append(tr)
    if len(trs) < period:
        return None
    # Simple average ATR
    return sum(trs[-period:]) / period

# Compute support signal stub

def compute_signal(macd_line, macd_signal, rsi_val):
    # Improved rules: add confidence scaling and avoid premature SELLs
    if macd_line is None or macd_signal is None or rsi_val is None:
        return ('HOLD', 'LOW')

    # BUY: bullish crossover + not overbought
    if macd_line > macd_signal and rsi_val < 70:
        confidence = 'HIGH' if rsi_val < 60 else 'MEDIUM'
        return ('BUY', confidence)

    # SELL: bearish crossover + overbought
    if macd_line < macd_signal and rsi_val > 70:
        confidence = 'HIGH' if rsi_val > 80 else 'MEDIUM'
        return ('SELL', confidence)

    # HOLD: neutral or conflicting signals
    return ('HOLD', 'LOW')


# --- Helpers for safe trading execution (optional and gated) ---
def _get_kite_client_from_secrets(secret_name=None):
    """Return a KiteConnect client configured with access token from Secrets Manager.
    Caller must handle exceptions. This function expects the secret to contain api_key and access_token.
    """
    try:
        from kiteconnect import KiteConnect
    except Exception:
        logger.warning('KiteConnect library not available in this environment.')
        return None
    secret_name = secret_name or os.environ.get('SECRET_NAME', 'autotrade-kite/credentials')
    sm = boto3.client('secretsmanager')
    sec = sm.get_secret_value(SecretId=secret_name)
    creds = json.loads(sec.get('SecretString') or '{}')
    api_key = creds.get('api_key') or creds.get('KITE_API_KEY')
    access_token = creds.get('access_token')
    if not api_key or not access_token:
        logger.warning('Kite credentials missing in Secrets Manager')
        return None
    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)
    return kite


def _get_account_balance(kite):
    """Attempt to fetch available cash/balance from Kite. Returns float or None."""
    try:
        # method name may vary depending on KiteConnect version; try margins first
        resp = kite.margins('equity') if hasattr(kite, 'margins') else None
        if resp and isinstance(resp, dict):
            # many implementations include e.g., 'available' or nested structure; best-effort
            for k in ('available', 'available_cash', 'net', 'equity'):
                if k in resp:
                    try:
                        return float(resp.get(k) or 0)
                    except Exception:
                        continue
        # fallback: try profile/holdings endpoints
        if hasattr(kite, 'profile'):
            p = kite.profile()
            if isinstance(p, dict) and p.get('equity'):
                return float(p.get('equity'))
    except Exception as e:
        logger.debug('Account balance fetch failed: %s', e)
    return None


def _has_open_order_for_symbol(kite, tradingsymbol, side=None):
    """Return True if there is an open/triggered order for this tradingsymbol (best-effort)."""
    try:
        orders = kite.orders()
        for o in orders:
            if o.get('tradingsymbol') == tradingsymbol and o.get('status') in ('OPEN', 'TRIGGER PENDING', 'PENDING'):
                if side:
                    if o.get('transaction_type') == side:
                        return True
                else:
                    return True
    except Exception as e:
        logger.debug('Failed to list orders: %s', e)
    return False


def _compute_quantity_from_allocation(price, allocation_pct, available_balance, min_trade_value=100):
    """Compute integer quantity based on percentage allocation of available_balance and current price.
    Returns 0 if allocation too small.
    """
    try:
        allocation_value = (allocation_pct / 100.0) * available_balance
        if allocation_value < min_trade_value:
            return 0
        qty = int(allocation_value / price)
        return max(0, qty)
    except Exception as e:
        logger.debug('Quantity calculation failed: %s', e)
        return 0


def _place_order_with_stop(kite, tradingsymbol, exchange, side, qty, price=None, stop_pct=0.02, trailing=False):
    """Place a primary LIMIT order and a stop-loss order as a separate order (best-effort).
    This function is intentionally cautious and logs failures rather than raising.
    """
    try:
        if qty <= 0:
            logger.info('Quantity computed as 0, skipping order placement for %s', tradingsymbol)
            return None
        # Place LIMIT order (buyer/seller)
        order_params = dict(
            variety='regular',
            exchange=exchange,
            tradingsymbol=tradingsymbol,
            transaction_type=side,
            quantity=qty,
            order_type='LIMIT' if price else 'MARKET',
            product='MIS',
        )
        if price:
            order_params['price'] = round(price, 2)
        logger.info('Placing primary order: %s', order_params)
        resp = kite.place_order(**order_params)
        logger.info('Primary order response: %s', resp)

        # Place stop-loss order as simple SL (best-effort). For BUY, SL will be below; for SELL, SL above.
        if price:
            if side == 'BUY':
                trigger_price = round(price * (1 - stop_pct), 2)
            else:
                trigger_price = round(price * (1 + stop_pct), 2)
            sl_params = dict(
                variety='regular',
                exchange=exchange,
                tradingsymbol=tradingsymbol,
                transaction_type=('SELL' if side == 'BUY' else 'BUY'),
                quantity=qty,
                order_type='SL',
                trigger_price=trigger_price,
                product='MIS',
            )
            try:
                logger.info('Placing stop-loss order: %s', sl_params)
                sl_resp = kite.place_order(**sl_params)
                logger.info('Stop-loss order response: %s', sl_resp)
            except Exception as e:
                logger.error('Stop-loss placement failed: %s', e)
        return resp
    except Exception as e:
        logger.error('Order placement failed: %s', e)
        return None

# Helper to convert Decimal types
def decimalize(v):
    try:
        return Decimal(str(v))
    except Exception:
        return None

# Main handler: process DynamoDB Stream events, for updated/new items compute indicators and update item

def lambda_handler(event, context):
    # Test mode: if invoked with {"test_notification": true} send a test notification and return
    try:
        if isinstance(event, dict) and event.get('test_notification'):
            msg = event.get('test_message', 'Test notification from tradebot-analysis-lambda')
            notify_telegram(f"[TEST] {msg}")
            notify_email('Test notification from analysis lambda', msg)
            return {'status': 'test_sent'}
    except Exception:
        logger.exception('Failed running test notification')
    # Accept DynamoDB stream events or a simple list/dict payload for manual testing
    records = []
    if isinstance(event, dict) and event.get('Records') and isinstance(event.get('Records'), list):
        records = event.get('Records', [])
    elif isinstance(event, list):
        # Normalize list of simple items into pseudo-stream records
        for itm in event:
            records.append({'eventName': 'INSERT', 'dynamodb': {'NewImage': {k: {'S': str(v)} for k, v in itm.items()}}})
    elif isinstance(event, dict):
        # Single item payload
        records = [{'eventName': 'INSERT', 'dynamodb': {'NewImage': {k: {'S': str(v)} for k, v in event.items()}}}]
    # If invoked with a backfill instruction, run backfill mode
    # Flags: allow forcing updates (override if_not_exists) and executing trades
    override_updates = False
    execute_trades = False
    enable_trading_env = os.environ.get('ENABLE_TRADING', 'false').lower() == 'true'
    if isinstance(event, dict):
        # allow EventBridge to pass {'override': true} to force updates during testing
        override_updates = bool(event.get('override') or event.get('force_update') or os.environ.get('FORCE_UPDATE', 'false').lower() == 'true')
        execute_trades = bool(event.get('execute_trades', False))
    if isinstance(event, dict) and event.get('backfilldays'):
        try:
            backfill_days = int(event.get('backfilldays', 1))
        except Exception:
            backfill_days = 1
        symbols = event.get('symbols')
        # If symbols not provided, derive set of symbols from table (scan projection)
        if not symbols:
            # obtain unique symbols via a scan (projection) - paginated
            symbols = set()
            resp = table.scan(ProjectionExpression='SymbolKey')
            for it in resp.get('Items', []):
                symbols.add(it.get('SymbolKey'))
            while 'LastEvaluatedKey' in resp:
                resp = table.scan(ProjectionExpression='SymbolKey', ExclusiveStartKey=resp['LastEvaluatedKey'])
                for it in resp.get('Items', []):
                    symbols.add(it.get('SymbolKey'))
            symbols = list(symbols)

        logger.info('Running backfill for symbols=%s for last %s days', symbols, backfill_days)
        results = {}
        threshold_date = (datetime.utcnow().date() - timedelta(days=backfill_days-1)).isoformat()
        from boto3.dynamodb.conditions import Key
        for symbol in symbols:
            # Query all items for symbol in ascending TradedDate
            resp = table.query(KeyConditionExpression=Key('SymbolKey').eq(symbol), ScanIndexForward=True)
            items = resp.get('Items', [])
            while 'LastEvaluatedKey' in resp:
                resp = table.query(KeyConditionExpression=Key('SymbolKey').eq(symbol), ExclusiveStartKey=resp['LastEvaluatedKey'], ScanIndexForward=True)
                items.extend(resp.get('Items', []))

            # Filter to items within threshold (>= threshold_date)
            to_process = [it for it in items if it.get('TradedDate') and it.get('TradedDate') >= threshold_date]
            logger.info('Symbol %s total items=%d to process=%d', symbol, len(items), len(to_process))
            # Precompute arrays
            closes_all = [float(x.get('Close', 0)) for x in items]
            highs_all = [float(x.get('High', 0)) for x in items]
            lows_all = [float(x.get('Low', 0)) for x in items]

            updates = 0
            # Iterate through items and update when within the target days
            for idx, item in enumerate(items):
                traded = item.get('TradedDate')
                if not traded or traded < threshold_date:
                    continue
                # compute using history up to idx
                sub_closes = closes_all[:idx+1]
                sub_highs = highs_all[:idx+1]
                sub_lows = lows_all[:idx+1]

                ma20 = ma(sub_closes, 20)
                ma50 = ma(sub_closes, 50)
                ma200 = ma(sub_closes, 200)
                rsi14 = rsi(sub_closes, 14)
                macd_line, macd_signal, macd_hist = macd(sub_closes)
                atr_val = atr(sub_highs, sub_lows, sub_closes, 14)
                signal, confidence = compute_signal(macd_line, macd_signal, rsi14)

                # Build update expression only for missing computed fields
                update_parts = []
                expr_vals = {}
                expr_names = {}
                if ma20 is not None:
                    if override_updates:
                        update_parts.append('MA20 = :ma20')
                    else:
                        update_parts.append('MA20 = if_not_exists(MA20, :ma20)')
                    expr_vals[':ma20'] = decimalize(round(ma20,2))
                if ma50 is not None:
                    if override_updates:
                        update_parts.append('MA50 = :ma50')
                    else:
                        update_parts.append('MA50 = if_not_exists(MA50, :ma50)')
                    expr_vals[':ma50'] = decimalize(round(ma50,2))
                if ma200 is not None:
                    if override_updates:
                        update_parts.append('MA200 = :ma200')
                    else:
                        update_parts.append('MA200 = if_not_exists(MA200, :ma200)')
                    expr_vals[':ma200'] = decimalize(round(ma200,2))
                if rsi14 is not None:
                    if override_updates:
                        update_parts.append('RSI14 = :rsi14')
                    else:
                        update_parts.append('RSI14 = if_not_exists(RSI14, :rsi14)')
                    expr_vals[':rsi14'] = decimalize(round(rsi14,2))
                if macd_line is not None:
                    if override_updates:
                        update_parts.append('MACD = :macd')
                    else:
                        update_parts.append('MACD = if_not_exists(MACD, :macd)')
                    expr_vals[':macd'] = decimalize(round(macd_line,2))
                if macd_signal is not None:
                    if override_updates:
                        update_parts.append('MACDSignal = :macd_sig')
                    else:
                        update_parts.append('MACDSignal = if_not_exists(MACDSignal, :macd_sig)')
                    expr_vals[':macd_sig'] = decimalize(round(macd_signal,2))
                if macd_hist is not None:
                    if override_updates:
                        update_parts.append('MACDHist = :macd_hist')
                    else:
                        update_parts.append('MACDHist = if_not_exists(MACDHist, :macd_hist)')
                    expr_vals[':macd_hist'] = decimalize(round(macd_hist,2))
                if atr_val is not None:
                    if override_updates:
                        update_parts.append('ATR = :atr')
                    else:
                        update_parts.append('ATR = if_not_exists(ATR, :atr)')
                    expr_vals[':atr'] = decimalize(round(atr_val,2))
                # Signal and Confidence
                if override_updates:
                    update_parts.append('Signal = :signal')
                    update_parts.append('Confidence = :conf')
                else:
                    update_parts.append('Signal = if_not_exists(Signal, :signal)')
                    update_parts.append('Confidence = if_not_exists(Confidence, :conf)')
                expr_vals[':signal'] = signal
                expr_vals[':conf'] = confidence

                if not update_parts:
                    continue

                update_expr = 'SET ' + ', '.join(update_parts)
                # reserved names handling - replace only whole-word occurrences so we don't
                # accidentally change names like MACDSignal
                if re.search(r"\bSignal\b", update_expr):
                    expr_names['#sig'] = 'Signal'
                    update_expr = re.sub(r"\bSignal\b", '#sig', update_expr)
                if re.search(r"\bConfidence\b", update_expr):
                    expr_names['#conf'] = 'Confidence'
                    update_expr = re.sub(r"\bConfidence\b", '#conf', update_expr)

                key = {'SymbolKey': item['SymbolKey'], 'TradedDate': item['TradedDate']}
                kwargs = dict(
                    Key=key,
                    UpdateExpression=update_expr,
                    ExpressionAttributeValues=expr_vals
                )
                if expr_names:
                    kwargs['ExpressionAttributeNames'] = expr_names
                try:
                    table.update_item(**kwargs)
                    updates += 1
                except ClientError as e:
                    logger.error('Backfill UpdateItem failed for %s: %s', key, e)
            results[symbol] = updates
        logger.info('Backfill results: %s', results)
        return {'status': 'backfill_done', 'results': results}

    logger.info('Received event with %d records', len(records))
    for rec in records:
        if rec.get('eventName') not in ('INSERT', 'MODIFY'):
            continue
        newImg = rec.get('dynamodb', {}).get('NewImage')
        if not newImg:
            continue
        # Extract symbol and date
        symbol = newImg.get('SymbolKey', {}).get('S')
        if not symbol:
            continue
        logger.info('Processing symbol %s', symbol)
        # Gather close prices, highs, lows, closes from table (recent items for that symbol)
        try:
            resp = table.scan(FilterExpression=boto3.dynamodb.conditions.Attr('SymbolKey').eq(symbol))
            items = resp.get('Items', [])
            # Sort by TradedDate or Timestamp
            items_sorted = sorted(items, key=lambda x: x.get('TradedDate', x.get('Timestamp', '')))
            closes = [float(x.get('Close', 0)) for x in items_sorted]
            highs = [float(x.get('High', 0)) for x in items_sorted]
            lows = [float(x.get('Low', 0)) for x in items_sorted]
        except ClientError as e:
            logger.error('DynamoDB scan failed: %s', e)
            continue

        # Determine which analysis fields are missing in the incoming image and only update those
        analysis_keys = ['MA20','MA50','MA200','RSI14','MACD','MACDSignal','MACDHist','Signal','Confidence','ATR']
        missing_keys = [k for k in analysis_keys if k not in newImg]
        tradedDate = newImg.get('TradedDate', {}).get('S')
        if not missing_keys:
            logger.info('All analysis fields present for %s %s, skipping', symbol, tradedDate)
            continue

        # Compute indicators (we compute all, but will only write missing ones)
        ma20 = ma(closes, 20)
        ma50 = ma(closes, 50)
        ma200 = ma(closes, 200)
        rsi14 = rsi(closes, 14)
        macd_line, macd_signal, macd_hist = macd(closes)
        atr_val = atr(highs, lows, closes, 14)

        # Simple signal & confidence
        signal, confidence = compute_signal(macd_line, macd_signal, rsi14)

        # Optionally execute trades based on signal. This is gated by ENABLE_TRADING env var and
        # an explicit execute_trades flag in the event to avoid accidental live orders.
        try:
            if signal in ('BUY', 'SELL') and enable_trading_env and execute_trades:
                # Build tradingsymbol & exchange from SymbolKey (user's convention: may be 'NSE:RELIANCE')
                tradingsymbol = symbol
                exchange = os.environ.get('DEFAULT_EXCHANGE', 'NSE')
                if ':' in symbol:
                    exchange, tradingsymbol = symbol.split(':', 1)

                kite = _get_kite_client_from_secrets()
                if kite is None:
                    logger.warning('Kite client not available; skipping trade execution for %s', symbol)
                else:
                    # check existing open orders to avoid duplicates
                    if _has_open_order_for_symbol(kite, tradingsymbol, side=signal):
                        logger.info('Open order exists for %s %s, skipping duplicate order', tradingsymbol, signal)
                        notify_telegram(f"Skipped duplicate {signal} order for {tradingsymbol} (existing open order)")
                    else:
                        # allocation percent provided via env or default 2%
                        allocation_pct = float(os.environ.get('TRADE_ALLOCATION_PCT', '2'))
                        # get available balance
                        avail = _get_account_balance(kite) or 0.0
                        # get current market price best-effort via kite.ltp if available
                        price = None
                        try:
                            if hasattr(kite, 'ltp'):
                                ltp = kite.ltp(f"{exchange}:{tradingsymbol}")
                                # ltp dict shape depends on API; best-effort read
                                for v in ltp.values():
                                    if isinstance(v, dict) and v.get('last_price'):
                                        price = float(v.get('last_price'))
                                        break
                        except Exception as e:
                            logger.debug('Failed to fetch ltp for %s: %s', tradingsymbol, e)

                        qty = _compute_quantity_from_allocation(price or (float(item.get('Close', 0)) if item else 0), allocation_pct, avail)
                        if qty <= 0:
                            logger.info('Computed qty 0 for %s using allocation %s%% and available %s, skipping', tradingsymbol, allocation_pct, avail)
                            notify_telegram(f"Not placing {signal} for {tradingsymbol}: allocation too small or insufficient balance.")
                        else:
                            res = _place_order_with_stop(kite, tradingsymbol, exchange, signal, qty, price=price, stop_pct=float(os.environ.get('DEFAULT_SL_PCT', '0.02')))
                            if res:
                                notify_telegram(f"Placed {signal} order for {tradingsymbol} qty={qty} confidence={confidence}")
                                # Optionally write order marker back to DynamoDB to avoid duplicates in future
                                if override_updates:
                                    try:
                                        table.update_item(Key={'SymbolKey': symbol, 'TradedDate': tradedDate}, UpdateExpression='SET LastOrder = :o', ExpressionAttributeValues={':o': json.dumps({'side': signal, 'qty': qty, 'resp': res})})
                                    except Exception as e:
                                        logger.error('Failed writing LastOrder marker: %s', e)
                            else:
                                notify_telegram(f"Failed placing {signal} order for {tradingsymbol} (see logs)")
        except Exception as e:
            logger.exception('Error during trade execution logic: %s', e)

        # Build update expression only for missing computed fields
        update_parts = []
        expr_vals = {}

        if 'MA20' in missing_keys and ma20 is not None:
            update_parts.append('MA20 = if_not_exists(MA20, :ma20)')
            expr_vals[':ma20'] = decimalize(round(ma20,2))
        if 'MA50' in missing_keys and ma50 is not None:
            update_parts.append('MA50 = if_not_exists(MA50, :ma50)')
            expr_vals[':ma50'] = decimalize(round(ma50,2))
        if 'MA200' in missing_keys and ma200 is not None:
            update_parts.append('MA200 = if_not_exists(MA200, :ma200)')
            expr_vals[':ma200'] = decimalize(round(ma200,2))
        if 'RSI14' in missing_keys and rsi14 is not None:
            update_parts.append('RSI14 = if_not_exists(RSI14, :rsi14)')
            expr_vals[':rsi14'] = decimalize(round(rsi14,2))
        if 'MACD' in missing_keys and macd_line is not None:
            update_parts.append('MACD = if_not_exists(MACD, :macd)')
            expr_vals[':macd'] = decimalize(round(macd_line,2))
        if 'MACDSignal' in missing_keys and macd_signal is not None:
            update_parts.append('MACDSignal = if_not_exists(MACDSignal, :macd_sig)')
            expr_vals[':macd_sig'] = decimalize(round(macd_signal,2))
        if 'MACDHist' in missing_keys and macd_hist is not None:
            update_parts.append('MACDHist = if_not_exists(MACDHist, :macd_hist)')
            expr_vals[':macd_hist'] = decimalize(round(macd_hist,2))
        if 'Signal' in missing_keys and signal is not None:
            update_parts.append('Signal = if_not_exists(Signal, :signal)')
            expr_vals[':signal'] = signal
        if 'Confidence' in missing_keys and confidence is not None:
            update_parts.append('Confidence = if_not_exists(Confidence, :conf)')
            expr_vals[':conf'] = confidence
        if 'ATR' in missing_keys and atr_val is not None:
            update_parts.append('ATR = if_not_exists(ATR, :atr)')
            expr_vals[':atr'] = decimalize(round(atr_val,2))

        if not update_parts:
            logger.info('No computed values to write for %s %s, skipping', symbol, tradedDate)
            continue

        update_expr = 'SET ' + ', '.join(update_parts)

        # Handle reserved keywords (e.g., 'Signal' and 'Confidence') by using ExpressionAttributeNames
        expr_names = {}
        if re.search(r"\bSignal\b", update_expr):
            expr_names['#sig'] = 'Signal'
            update_expr = re.sub(r"\bSignal\b", '#sig', update_expr)
        if re.search(r"\bConfidence\b", update_expr):
            expr_names['#conf'] = 'Confidence'
            update_expr = re.sub(r"\bConfidence\b", '#conf', update_expr)

        # Update the item(s) - it depends on key schema; assume primary key is SymbolKey + TradedDate
        tradedDate = newImg.get('TradedDate', {}).get('S')
        pk = symbol
        sk = tradedDate
        try:
            kwargs = dict(
                Key={'SymbolKey': pk, 'TradedDate': sk},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_vals
            )
            if expr_names:
                kwargs['ExpressionAttributeNames'] = expr_names
            table.update_item(**kwargs)
            logger.info('Updated indicators for %s %s', symbol, tradedDate)
        except ClientError as e:
            logger.error('UpdateItem failed: %s', e)
    return {'status': 'done'}
