import boto3
import json
import requests
import os
from datetime import datetime

def get_alpaca_keys():
    """Retrieve Alpaca API keys from AWS Secrets Manager"""
    print("🔑 Starting to retrieve Alpaca API keys from Secrets Manager...")
    client = boto3.client('secretsmanager')
    secret_name = "swing-alpaca/papter-trading/keys"
    print(f"📋 Secret name: {secret_name}")
    try:
        print("🔍 Calling get_secret_value...")
        response = client.get_secret_value(SecretId=secret_name)
        print("✅ Successfully retrieved secret from AWS")
        secret = json.loads(response['SecretString'])
        print(f"🔧 Secret keys found: {list(secret.keys())}")
        return secret['ALPACA_API_KEY'], secret['ALPACA_SECRET_KEY']
    except Exception as e:
        print(f"❌ Error retrieving secrets: {e}")
        raise

# Initialize outside handler for better performance
print("🚀 Starting Lambda initialization...")
try:
    API_KEY, SECRET_KEY = get_alpaca_keys()
    print(f"✅ API keys retrieved successfully (API_KEY length: {len(API_KEY) if API_KEY else 0})")
    BASE_URL = "https://data.alpaca.markets"
    print(f"🌐 Base URL set: {BASE_URL}")
    HEADERS = {
        "APCA-API-KEY-ID": API_KEY,
        "APCA-API-SECRET-KEY": SECRET_KEY
    }
    print("📝 Headers configured for Alpaca API")
    s3_client = boto3.client('s3')
    S3_BUCKET = os.environ.get('S3_BUCKET', 'swing-automation-data-processor')
    print(f"🪣 S3 bucket configured: {S3_BUCKET}")
    print("✅ Initialization completed successfully")
except Exception as e:
    print(f"❌ Initialization error: {e}")
    API_KEY = SECRET_KEY = None

def get_bars(symbol, timeframe="1Day", limit=30):
    """Fetch historical price data from Alpaca"""
    print(f"📊 Fetching {limit} {timeframe} bars for {symbol}...")
    
    url = f"{BASE_URL}/v2/stocks/{symbol}/bars"
    params = {
        "timeframe": timeframe,
        "limit": limit
    }
    print(f"🔗 API URL: {url}")
    print(f"📋 Parameters: {params}")
    try:
        print(f"🌐 Making API request to Alpaca...")
        response = requests.get(url, headers=HEADERS, params=params)
        print(f"📡 Response status: {response.status_code}")
        
        if response.status_code != 200:
            print(f"❌ API Error Response: {response.text}")
        
        response.raise_for_status()
        data = response.json()
        print(f"🔍 Full API response: {json.dumps(data, indent=2)[:500]}...")
        
        bars = data.get('bars', [])
        print(f"📈 Received {len(bars)} bars for {symbol}")
        
        if not bars:
            print(f"⚠️ No bars returned for {symbol}")
            return []
            
        prices = [float(bar['c']) for bar in bars]
        print(f"💰 Price range: ${min(prices):.2f} - ${max(prices):.2f}")
        return prices
    except Exception as e:
        print(f"❌ Error fetching data for {symbol}: {e}")
        import traceback
        print(f"📋 Full error traceback: {traceback.format_exc()}")
        return []

def calculate_rsi(prices, period=14):
    """Calculate RSI indicator"""
    print(f"📊 Calculating RSI with {len(prices)} prices, period={period}")
    if len(prices) < period + 1:
        print(f"⚠️ Not enough data for RSI calculation, returning neutral (50)")
        return 50  # Default neutral RSI
    
    gains, losses = [], []
    for i in range(1, len(prices)):
        delta = prices[i] - prices[i-1]
        gains.append(max(delta, 0))
        losses.append(max(-delta, 0))
    
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    print(f"📈 Avg Gain: {avg_gain:.4f}, Avg Loss: {avg_loss:.4f}")
    
    if avg_loss == 0:
        print("📈 No losses detected, RSI = 100")
        return 100
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    print(f"📊 Calculated RSI: {rsi:.2f}")
    return rsi

def calculate_ema(prices, period=20):
    """Calculate Exponential Moving Average"""
    print(f"📊 Calculating EMA with {len(prices)} prices, period={period}")
    if len(prices) < period:
        simple_avg = sum(prices) / len(prices)
        print(f"⚠️ Not enough data for full EMA, using simple average: {simple_avg:.2f}")
        return simple_avg  # Simple average if not enough data
    
    ema = prices[0]
    multiplier = 2 / (period + 1)
    print(f"🔢 EMA multiplier: {multiplier:.4f}")
    for price in prices[1:]:
        ema = (price - ema) * multiplier + ema
    print(f"📊 Calculated EMA: {ema:.2f}")
    return ema

def save_to_s3(data, filename):
    """Save analysis data to S3"""
    print(f"💾 Attempting to save data to S3: {filename}")
    print(f"🪣 Target bucket: {S3_BUCKET}")
    print(f"📁 S3 key: analysis/{filename}")
    try:
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=f"analysis/{filename}",
            Body=json.dumps(data, indent=2),
            ContentType='application/json'
        )
        print(f"✅ Data successfully saved to S3: {filename}")
    except Exception as e:
        print(f"❌ Error saving to S3: {e}")

def lambda_handler(event, context):
    """Main Lambda handler"""
    print("🎯 Lambda handler started")
    print(f"📥 Received event: {json.dumps(event, indent=2)}")
    print(f"🔧 Context: {context}")
    
    if not API_KEY or not SECRET_KEY:
        print("❌ API keys not configured")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'API keys not configured'})
        }
    
    print("✅ API keys are configured")
    
    # Symbols to analyze
    symbols = event.get('symbols', ['AAPL', 'MSFT', 'GOOGL'])
    print(f"📈 Symbols to analyze: {symbols}")
    results = []
    
    for i, symbol in enumerate(symbols, 1):
        print(f"\n🔄 Processing symbol {i}/{len(symbols)}: {symbol}")
        try:
            # Fetch price data
            prices = get_bars(symbol)
            if not prices:
                print(f"⚠️ No price data received for {symbol}, skipping...")
                continue
            
            print(f"✅ Retrieved {len(prices)} price points for {symbol}")
            
            # Calculate indicators
            rsi = calculate_rsi(prices)
            ema = calculate_ema(prices)
            current_price = prices[-1]
            
            print(f"📊 Technical Analysis for {symbol}:")
            print(f"   💰 Current Price: ${current_price:.2f}")
            print(f"   📈 RSI: {rsi:.2f}")
            print(f"   📊 EMA: ${ema:.2f}")
            
            # Generate signal
            print(f"🎯 Signal Logic for {symbol}:")
            print(f"   RSI < 30? {rsi < 30} (RSI: {rsi:.2f})")
            print(f"   Price > EMA? {current_price > ema} (${current_price:.2f} vs ${ema:.2f})")
            print(f"   RSI > 70? {rsi > 70} (RSI: {rsi:.2f})")
            print(f"   Price < EMA? {current_price < ema} (${current_price:.2f} vs ${ema:.2f})")
            
            if rsi < 30 and current_price > ema:
                signal = "BUY"
                print(f"🟢 BUY signal generated for {symbol}")
            elif rsi > 70 and current_price < ema:
                signal = "SELL"
                print(f"🔴 SELL signal generated for {symbol}")
            else:
                signal = "HOLD"
                print(f"🟡 HOLD signal generated for {symbol}")
            
            # Prepare result
            result = {
                'symbol': symbol,
                'timestamp': datetime.utcnow().isoformat(),
                'price': round(current_price, 2),
                'rsi': round(rsi, 2),
                'ema': round(ema, 2),
                'signal': signal
            }
            
            results.append(result)
            print(f"✅ {symbol} analysis complete: {signal}")
            
        except Exception as e:
            print(f"❌ Error processing {symbol}: {e}")
            import traceback
            print(f"📋 Full traceback: {traceback.format_exc()}")
            continue
    
    print(f"\n📊 Analysis Summary:")
    print(f"   Total symbols processed: {len(results)}")
    for result in results:
        print(f"   {result['symbol']}: {result['signal']} (RSI: {result['rsi']}, Price: ${result['price']})")
    
    # Save results to S3
    if results:
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        filename = f"analysis_{timestamp}.json"
        print(f"\n💾 Saving results to S3...")
        save_to_s3(results, filename)
    else:
        print("⚠️ No results to save to S3")
    
    final_response = {
        'statusCode': 200,
        'body': json.dumps({
            'message': f'Processed {len(results)} symbols',
            'results': results
        })
    }
    
    print(f"\n🎯 Lambda execution completed successfully")
    print(f"📤 Final response: {json.dumps(final_response, indent=2)}")
    
    return final_response